from .orm import ORM


class Position(ORM):
    pass



