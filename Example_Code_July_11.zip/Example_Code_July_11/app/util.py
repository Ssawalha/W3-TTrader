from hashlib import sha256
import requests

FAKE_PRICES = {"symbol":"AAPL","companyName":"Apple, Inc.","calculationPrice":"close","open":201.85,"openTime":1562765400280,"close":203.23,"closeTime":1562788800542,"high":203.73,"low":201.56,"latestPrice":203.23,"latestSource":"Close","latestTime":"July 10, 2019","latestUpdate":1562788800542,"latestVolume":17876375,"iexRealtimePrice":203.18,"iexRealtimeSize":100,"iexLastUpdated":1562788799615,"delayedPrice":203.23,"delayedPriceTime":1562788800542,"extendedPrice":203.25,"extendedChange":0.02,"extendedChangePercent":0.0001,"extendedPriceTime":1562791802875,"previousClose":201.24,"change":1.99,"changePercent":0.00989,"iexMarketPercent":0.032331554915356164,"iexVolume":577971,"avgTotalVolume":24623542,"iexBidPrice":0,"iexBidSize":0,"iexAskPrice":0,"iexAskSize":0,"marketCap":935077488400,"peRatio":16.95,"week52High":233.47,"week52Low":142,"ytdChange":0.284206,"lastTradeTime":1562788800542}
API_KEY = ""

def hash_password(password, salt='salt'):
        # TODO: add hashing and salt funcitonality
        return password

def lookup_price(ticker):
        global API_KEY
        ticker = ticker.lower()
        stem = "https://cloud.iexapis.com/stable/stock/{}/quote?token="
        response = requests.get((stem.format(ticker) + API_KEY))
        price = response.json()["latestPrice"]
        return price

def get_token():
        with open('tokenfile.txt') as infile:
                token = infile.read()
                return token

API_KEY = get_token()
print(lookup_price('aapl'))