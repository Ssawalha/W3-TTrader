import sqlite3
from collections import OrderedDict
from app.orm import orm
from app.util import hash_password
from app.position import Position

class Account(ORM):

    tablename = "accounts"
    fields = ["username", "password_hash", "balance"]

    createsql = """ """

    def __init__(self, **kwargs):
        self.values = OrderedDict()
        self.values['pk'] = kwargs.get('pk')
        self.values['username'] = kwargs.get('username')
        self.values['password_hash'] = kwargs.get('password_hash')
        self.values['balance'] = kwargs.get('balance')

    @classmethod
    def login(cls, username, password):
        """ login TODO: check password hash """
        return cls.select_one_where("WHERE username = ? and password_hash = ?",
                                    (username, hash_password(password)))

    def get_positions(self):
        return Position.select_many_where("WHERE accounts_pk =?", (self.value['pk'],))

    def get_position_for(self, ticker):
        """ return a Position object for the user. if the position does not 
        exist, return a new Position with zero shares."""
        position = Position.select_one_where(
            "WHERE ticker =? AND accounts_pk =?", (ticker, self.values['pk']))
        if position is None:
            return Position(ticker=ticker, accounts_pk=self.values['pk'], shares=0)
        return position

    def get_trades(self):
        """ return all of the user's trades ordered by time. returns a list of
        Trade objects """
        return []

    def trades_for(self, ticker):
        """ return all of the user's trades for a given ticker. """
        return []
    
    def buy(self, ticker, amount):
        """ make a purchase! raise KeyError for a nonexistent stock and
        ValueError for insufficient funds. will create a new Trade and modify
        a Position and alters the user's balance. returns nothing """
        pass

    def sell(self, ticker, amount):
        """ make a sale! raise KeyError for a non-existent Position and
        ValueError for insufficient shares. will create a new Trade object,
        modify a Position, and alter the self.balance. returns nothing."""
        pass
